// Placeholder for Exercise 10
public class Exercise10 {
    public static void main(String[] args) {
        System.out.println("Exercise 10 solution goes here.");
    }
}