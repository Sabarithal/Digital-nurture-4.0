// Placeholder for Exercise 11
public class Exercise11 {
    public static void main(String[] args) {
        System.out.println("Exercise 11 solution goes here.");
    }
}