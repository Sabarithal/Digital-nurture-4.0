// Placeholder for Exercise 12
public class Exercise12 {
    public static void main(String[] args) {
        System.out.println("Exercise 12 solution goes here.");
    }
}