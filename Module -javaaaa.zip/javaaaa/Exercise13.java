// Placeholder for Exercise 13
public class Exercise13 {
    public static void main(String[] args) {
        System.out.println("Exercise 13 solution goes here.");
    }
}