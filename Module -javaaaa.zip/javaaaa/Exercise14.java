// Placeholder for Exercise 14
public class Exercise14 {
    public static void main(String[] args) {
        System.out.println("Exercise 14 solution goes here.");
    }
}