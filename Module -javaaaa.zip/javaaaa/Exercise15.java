// Placeholder for Exercise 15
public class Exercise15 {
    public static void main(String[] args) {
        System.out.println("Exercise 15 solution goes here.");
    }
}