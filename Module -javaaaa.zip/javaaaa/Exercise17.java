// Placeholder for Exercise 17
public class Exercise17 {
    public static void main(String[] args) {
        System.out.println("Exercise 17 solution goes here.");
    }
}