// Placeholder for Exercise 18
public class Exercise18 {
    public static void main(String[] args) {
        System.out.println("Exercise 18 solution goes here.");
    }
}