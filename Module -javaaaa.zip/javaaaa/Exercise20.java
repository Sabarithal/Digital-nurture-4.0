// Placeholder for Exercise 20
public class Exercise20 {
    public static void main(String[] args) {
        System.out.println("Exercise 20 solution goes here.");
    }
}