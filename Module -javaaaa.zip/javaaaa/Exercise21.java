// Placeholder for Exercise 21
public class Exercise21 {
    public static void main(String[] args) {
        System.out.println("Exercise 21 solution goes here.");
    }
}