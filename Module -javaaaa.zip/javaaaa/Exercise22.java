// Placeholder for Exercise 22
public class Exercise22 {
    public static void main(String[] args) {
        System.out.println("Exercise 22 solution goes here.");
    }
}