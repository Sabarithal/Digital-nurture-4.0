// Placeholder for Exercise 25
public class Exercise25 {
    public static void main(String[] args) {
        System.out.println("Exercise 25 solution goes here.");
    }
}