// Placeholder for Exercise 26
public class Exercise26 {
    public static void main(String[] args) {
        System.out.println("Exercise 26 solution goes here.");
    }
}