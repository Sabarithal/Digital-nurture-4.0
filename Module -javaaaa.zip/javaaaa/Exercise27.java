// Placeholder for Exercise 27
public class Exercise27 {
    public static void main(String[] args) {
        System.out.println("Exercise 27 solution goes here.");
    }
}