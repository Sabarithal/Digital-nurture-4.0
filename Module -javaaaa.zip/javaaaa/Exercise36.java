// Placeholder for Exercise 36
public class Exercise36 {
    public static void main(String[] args) {
        System.out.println("Exercise 36 solution goes here.");
    }
}