// Placeholder for Exercise 40
public class Exercise40 {
    public static void main(String[] args) {
        System.out.println("Exercise 40 solution goes here.");
    }
}