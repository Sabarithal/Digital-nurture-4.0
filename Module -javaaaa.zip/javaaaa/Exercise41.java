// Placeholder for Exercise 41
public class Exercise41 {
    public static void main(String[] args) {
        System.out.println("Exercise 41 solution goes here.");
    }
}