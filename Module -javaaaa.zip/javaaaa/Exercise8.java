// Placeholder for Exercise 8
public class Exercise8 {
    public static void main(String[] args) {
        System.out.println("Exercise 8 solution goes here.");
    }
}