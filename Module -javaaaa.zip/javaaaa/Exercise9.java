// Placeholder for Exercise 9
public class Exercise9 {
    public static void main(String[] args) {
        System.out.println("Exercise 9 solution goes here.");
    }
}