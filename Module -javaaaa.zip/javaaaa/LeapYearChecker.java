import java.util.Scanner;

public class LeapYearChecker {
    public static void main(String[] args) {
        int year = new Scanner(System.in).nextInt();
        boolean isLeap = (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
        System.out.println(isLeap ? "Leap Year" : "Not a Leap Year");
    }
}