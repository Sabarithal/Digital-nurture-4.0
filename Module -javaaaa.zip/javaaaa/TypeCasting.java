public class TypeCasting {
    public static void main(String[] args) {
        double d = 9.78;
        int i = (int) d;
        int j = 5;
        double dj = j;
        System.out.println("Double to Int: " + i);
        System.out.println("Int to Double: " + dj);
    }
}