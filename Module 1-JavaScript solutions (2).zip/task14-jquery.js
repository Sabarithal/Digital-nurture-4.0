// jQuery example
$('#registerBtn').click(function() {
  alert('Registered with jQuery!');
});

$('.event-card').fadeIn();

$('.event-card').fadeOut(2000);